# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information



project = 'DIRECD'
copyright = '2025, Shantanu Jain'
author = 'Shantanu Jain'
release = '1.0.0'

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = ['sphinx_rtd_theme']

# templates_path = ['_templates']
# exclude_patterns = []



# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = "sphinx_rtd_theme"

# html_theme = 'alabaster'
html_static_path = ['_static']

# html_sidebars = {
#     '**': [
#         'about.html',
#         'searchfield.html',
#         'navigation.html',
#         'relations.html',
#         'donate.html',
#     ]
# }

html_logo = '../logo/DIRECD_logo_rs.jpg'
html_theme_options = {
    'logo_only': False,
    'display_version': True,
}
